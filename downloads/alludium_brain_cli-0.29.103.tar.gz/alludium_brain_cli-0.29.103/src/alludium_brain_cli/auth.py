"""MCP SDK OAuth with a loopback callback and OS credential storage."""

import asyncio
import hashlib
import json
import os
import secrets
import sys
import time
import webbrowser
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

import keyring
from filelock import FileLock
from mcp.client.auth import OAuthClientProvider
from mcp.shared.auth import (
    AuthorizationCodeResult,
    OAuthClientInformationFull,
    OAuthClientMetadata,
    OAuthMetadata,
    OAuthToken,
    ProtectedResourceMetadata,
)

from .errors import CliError

SERVICE = "alludium-brain-cli"


class LoginRequired(CliError):
    pass


def validate_server(url: str) -> str:
    parts = urlsplit(url)
    if parts.username or parts.password or parts.query or parts.fragment or not parts.hostname:
        raise CliError("Server must be an HTTPS MCP URL without credentials, query or fragment.")
    if parts.scheme != "https" and not (parts.scheme == "http" and parts.hostname in {"localhost", "127.0.0.1", "::1"}):
        raise CliError("Server requires HTTPS; HTTP is allowed only on loopback for development.")
    return url.rstrip("/")


class CredentialStore:
    def __init__(self, server: str, port: int):
        self.key = hashlib.sha256(f"{server}|{port}".encode()).hexdigest()
        self.context = None

    def read(self) -> dict:
        return json.loads(keyring.get_password(SERVICE, self.key) or "{}")

    def write(self, **updates):
        keyring.set_password(SERVICE, self.key, json.dumps({**self.read(), **updates}))

    async def get_tokens(self):
        data = self.read()
        if not data.get("tokens"):
            return None
        token = OAuthToken.model_validate(data["tokens"])
        if data.get("expires_at") is not None:
            token.expires_in = max(0, int(data["expires_at"] - time.time()))
        return token

    async def set_tokens(self, tokens):
        metadata = {}
        if self.context:
            context = self.context
            metadata = {
                "oauth_metadata": context.oauth_metadata.model_dump(mode="json") if context.oauth_metadata else None,
                "auth_server_url": context.auth_server_url,
                "protected_resource": (
                    context.protected_resource_metadata.model_dump(mode="json")
                    if context.protected_resource_metadata
                    else None
                ),
            }
        # Token and its discovered issuer metadata must be replaced together, including refresh.
        self.write(
            tokens=tokens.model_dump(mode="json"),
            expires_at=None if tokens.expires_in is None else time.time() + tokens.expires_in,
            **metadata,
        )

    async def get_client_info(self):
        data = self.read().get("client")
        return OAuthClientInformationFull.model_validate(data) if data else None

    async def set_client_info(self, client_info):
        self.write(client=client_info.model_dump(mode="json"))

    def clear(self):
        if keyring.get_password(SERVICE, self.key) is not None:
            keyring.delete_password(SERVICE, self.key)


class StoredOAuthClientProvider(OAuthClientProvider):
    """MCP 2.3 reloads tokens but not their expiry or discovered refresh endpoint.

    Keep these alongside the tokens in the keyring so a new CLI process refreshes against
    the validated issuer, never the resource server's fallback /token. Pin the SDK and test
    this small adapter when upgrading it.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.context.storage.context = self.context

    async def _initialize(self):
        await super()._initialize()
        saved = self.context.storage.read()
        metadata = saved.get("oauth_metadata")
        if self.context.current_tokens and metadata:
            self.context.oauth_metadata = OAuthMetadata.model_validate(metadata)
            self.context.auth_server_url = saved["auth_server_url"]
            if saved.get("protected_resource"):
                self.context.protected_resource_metadata = ProtectedResourceMetadata.model_validate(
                    saved["protected_resource"]
                )
            self.context.update_token_expiry(self.context.current_tokens)
        elif self.context.current_tokens:
            # Old/incomplete saved profiles must sign in again, not send a refresh token to
            # an endpoint whose origin we have not retained.
            self.context.current_tokens = None


class Callback:
    """Bound before opening the browser. SDK also validates state, issuer and PKCE."""

    def __init__(self):
        self.result = asyncio.get_running_loop().create_future()
        self.state = None

    async def redirect(self, url: str):
        self.state = parse_qs(urlsplit(url).query).get("state", [None])[0]
        if not self.state:
            raise LoginRequired("Authorization server supplied no state.")
        print("Opening your browser to sign in to Alludium Brain…", file=sys.stderr)
        if not webbrowser.open(url):
            raise LoginRequired("Could not open a browser. Run brain login on a computer with a browser.")

    async def handle(self, reader, writer):
        message, status = b"Invalid authorization callback.", "400 Bad Request"
        try:
            line = (await asyncio.wait_for(reader.readline(), 5)).decode("ascii")
            method, target, _ = line.split()
            parts = urlsplit(target)
            query = parse_qs(parts.query)
            state = query.get("state", [""])[0]
            if (
                method == "GET"
                and parts.path == "/callback"
                and self.state
                and secrets.compare_digest(state, self.state)
            ):
                if query.get("error"):
                    if not self.result.done():
                        self.result.set_exception(LoginRequired("Sign-in was declined. Run brain login to try again."))
                elif query.get("code") and not self.result.done():
                    self.result.set_result(
                        AuthorizationCodeResult(code=query["code"][0], state=state, iss=query.get("iss", [None])[0])
                    )
                    message, status = b"Sign-in received. You can close this tab and return to the terminal.", "200 OK"
        except (ValueError, UnicodeError, TimeoutError):
            pass
        finally:
            writer.write(
                f"HTTP/1.1 {status}\r\nContent-Type: text/plain\r\nConnection: close\r\n\r\n".encode() + message
            )
            await writer.drain()
            writer.close()
            await writer.wait_closed()

    async def receive(self):
        return await asyncio.wait_for(self.result, 180)


async def no_login(_url=None):
    raise LoginRequired("Sign-in required. Run brain login first; scripts never open a browser automatically.")


def profile_lock(store):
    # Refresh tokens can rotate. Serialize commands, including logout, for this profile.
    root = Path(os.environ.get("BRAIN_STATE_DIR", "~/.local/state/alludium-brain")).expanduser()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    return FileLock(root / f"{store.key}.lock", timeout=10)


@asynccontextmanager
async def credentials(server: str, port: int, login: bool = False):
    store = CredentialStore(server, port)
    with profile_lock(store):
        callback = Callback() if login else None
        listener = await asyncio.start_server(callback.handle, "127.0.0.1", port) if callback else None
        try:
            yield StoredOAuthClientProvider(
                server_url=server,
                client_metadata=OAuthClientMetadata(
                    client_name="Alludium Brain CLI",
                    redirect_uris=[f"http://127.0.0.1:{port}/callback"],
                    grant_types=["authorization_code", "refresh_token"],
                    response_types=["code"],
                    token_endpoint_auth_method="none",
                ),
                storage=store,
                redirect_handler=callback.redirect if callback else no_login,
                callback_handler=callback.receive if callback else no_login,
            )
        finally:
            if listener:
                listener.close()
                await listener.wait_closed()
