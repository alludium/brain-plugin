"""JSON stdout for scripts; diagnostics on stderr and nonzero status on any failure."""

import argparse
import asyncio
import json
import logging
import os
import sys
from importlib.metadata import version
from pathlib import Path

from .auth import CredentialStore, credentials, profile_lock, validate_server
from .client import connect, result_json, tools
from .errors import CliError, diagnostic
from .uploads import files, upload

DEFAULT_SERVER = "https://app.brain.alludium.ai/mcp"


def emit(data):
    print(json.dumps(data, ensure_ascii=False), flush=True)


def parser():
    ap = argparse.ArgumentParser(description="Alludium Brain: script its MCP tools without a model.")
    ap.add_argument("--version", action="version", version=version("alludium-brain-cli"))
    ap.add_argument("--server", default=os.environ.get("BRAIN_SERVER", DEFAULT_SERVER))
    ap.add_argument("--callback-port", type=int, default=8769)
    sub = ap.add_subparsers(dest="command", required=True)
    login = sub.add_parser("login", help="Sign in through your browser; save credentials in the OS keyring")
    login.add_argument(
        "--allow-keychain-prompt",
        action="store_true",
        help="Explicitly allow macOS Keychain approval dialogs for this login only",
    )
    sub.add_parser("logout", help="Remove this CLI profile's local credentials (does not revoke at the server)")
    sub.add_parser("tools", help="List live tools, descriptions and JSON input schemas")
    call = sub.add_parser("call", help="Call any tool; arguments come from a JSON file or stdin")
    call.add_argument("tool")
    call.add_argument("--input", default="-", help="JSON file; '-' reads stdin (default)")
    up = sub.add_parser("upload", help="Add files or a folder; repeat safely to add changed snapshots")
    up.add_argument("path", type=Path)
    up.add_argument("--namespace", required=True, help="Stable name for this collection, e.g. research-vault")
    up.add_argument("--scope", choices=["private", "firm"], default="private")
    up.add_argument("--dry-run", action="store_true", help="Local metadata only; no sign-in or network")
    jobs = sub.add_parser("jobs", help="Check whether uploaded files have finished processing")
    jobs.add_argument("ids", nargs="+")
    return ap


async def execute(args, session=None):
    if args.command == "tools":
        emit({"tools": await tools(session)})
    elif args.command == "login":
        result = await session.call_tool("configure", {})
        emit(result_json(result))  # includes caller/workspace so the user can check their identity
        return 1 if result.is_error else 0
    elif args.command in {"call", "jobs"}:
        if args.command == "call":
            raw = sys.stdin.read() if args.input == "-" else Path(args.input).read_text()
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise CliError("Tool input must be a JSON object.")
            name = args.tool
        else:
            if len(args.ids) > 50:
                raise CliError("Check at most 50 jobs at a time.")
            name, data = "job_status", {"job_ids": args.ids}
        result = await session.call_tool(name, data)
        emit(result_json(result))
        return 1 if result.is_error else 0
    elif args.command == "upload":
        if not args.namespace.strip():
            raise CliError("Namespace must not be empty.")
        failed = count = 0
        for path, relative in files(args.path.expanduser()):
            count += 1
            try:
                emit(await upload(session, path, relative, args.namespace, args.scope, args.dry_run))
            except Exception as exc:
                # Neither SDK exceptions nor HTTP exceptions are safe: they can include tokens/URLs.
                emit(
                    {
                        "path": relative,
                        "error": diagnostic(exc)
                        or "Upload failed; rerun to retry. Check sign-in, permissions and storage.",
                    }
                )
                failed += 1
        print(f"{count} files considered; {failed} failed.", file=sys.stderr)
        return 1 if failed or not count else 0
    return 0


async def run(args):
    args.server = validate_server(args.server)
    if not 1024 <= args.callback_port <= 65535:
        raise CliError("Callback port must be between 1024 and 65535.")
    if args.command == "logout":
        store = CredentialStore(args.server, args.callback_port)
        with profile_lock(store):
            store.clear()
        emit({"logged_out": True, "server": args.server})
        return 0
    if args.command == "upload" and args.dry_run:
        return await execute(args)
    token = os.environ.get("BRAIN_ACCESS_TOKEN")
    if token and args.command != "login":
        async with connect(args.server, token=token) as session:
            return await execute(args, session)
    async with (
        credentials(args.server, args.callback_port, login=args.command == "login") as auth,
        connect(args.server, auth=auth) as session,
    ):
        return await execute(args, session)


def main():
    # Transport logging can include signed URLs and bearer credentials; never forward it.
    logging.disable(logging.CRITICAL)
    args = parser().parse_args()
    try:
        status = asyncio.run(run(args))
    except KeyboardInterrupt:
        status = 130
    except Exception as exc:
        print(
            diagnostic(exc)
            or "Brain command failed. Check input, connection and OS keyring; run brain login if sign-in expired. "
            "No operation was automatically retried.",
            file=sys.stderr,
        )
        status = 1
    raise SystemExit(status)
