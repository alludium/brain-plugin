"""Additive folder imports using existing content-hashed uploads; no file bytes in stdout."""

import hashlib
import json
import os
import tempfile
from pathlib import Path

import httpx2

from .errors import CliError

TYPES = {
    ".pdf": "application/pdf",
    ".md": "text/markdown",
    ".markdown": "text/markdown",
    ".txt": "text/plain",
    ".html": "text/html",
    ".htm": "text/html",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}


def files(root: Path):
    if root.is_symlink():
        raise CliError("Choose a real file or directory, not a symbolic link.")
    if root.is_file():
        if root.suffix.lower() not in TYPES:
            raise CliError("Unsupported file type. Use brain tools to inspect other intake options.")
        yield root, root.name
    elif root.is_dir():
        for directory, dirs, names in os.walk(root, followlinks=False):
            dirs[:] = sorted(d for d in dirs if not d.startswith(".") and not (Path(directory) / d).is_symlink())
            for name in sorted(names):
                path = Path(directory) / name
                if not name.startswith((".", "~$")) and not path.is_symlink() and path.suffix.lower() in TYPES:
                    yield path, path.relative_to(root).as_posix()
    else:
        raise CliError("Upload path does not exist.")


def snapshot(path, out):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
            out.write(chunk)
    size = out.tell()
    out.seek(0)
    return digest.hexdigest(), size


async def chunks(file):
    while chunk := file.read(1024 * 1024):
        yield chunk


async def upload(session, path, relative, namespace, scope, dry_run=False):
    # One bounded-memory snapshot: a vault edited mid-transfer cannot invalidate its hash.
    with tempfile.TemporaryFile() as file:
        digest, size = snapshot(path, file)
        metadata = {
            "filename": path.name,
            "content_type": TYPES[path.suffix.lower()],
            "sha256": digest,
            "scope": scope,
            "system": "brain-cli",
            "external_id": hashlib.sha256(json.dumps([namespace, relative, digest]).encode()).hexdigest(),
            "hints": [relative],
        }
        receipt = {"path": relative, "sha256": digest, "bytes": size}
        if dry_run:
            return {**receipt, "dry_run": True, "request": metadata}
        result = await session.call_tool("request_upload", metadata)
        if result.is_error:
            # Avoid printing a transfer URL or arbitrary server body on a failed upload.
            raise CliError("request_upload refused this file; inspect its metadata and permissions.")
        plan = result.structured_content
        if not isinstance(plan, dict) or not plan.get("source_id") or not plan.get("job_id"):
            raise CliError("Server returned no upload receipt. Upgrade the CLI or check workspace selection.")
        if plan.get("upload_url"):
            url = httpx2.URL(plan["upload_url"])
            if url.scheme != "https" and not (url.scheme == "http" and url.host in {"127.0.0.1", "localhost", "::1"}):
                raise CliError("Server returned an insecure upload URL.")
            # Separate client: never send the Brain bearer credential to storage, or follow redirects.
            async with httpx2.AsyncClient(timeout=120, follow_redirects=False) as http:
                response = await http.put(
                    plan["upload_url"],
                    content=chunks(file),
                    headers={**plan.get("upload_headers", {}), "Content-Length": str(size)},
                )
                if not 200 <= response.status_code < 300:
                    raise CliError(f"Storage upload failed (HTTP {response.status_code}); rerun to retry.")
        return {
            **receipt,
            **{k: plan[k] for k in ("source_id", "job_id", "scope", "status", "created", "warnings") if k in plan},
            "transferred": bool(plan.get("upload_url")),
        }
