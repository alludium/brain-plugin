"""Sequential JSON Lines calls over one connection; acknowledge each before reading another."""

import asyncio
import json
import sys
from contextlib import nullcontext
from pathlib import Path

from .client import result_json
from .errors import CliError

MAX_LINE = 32 * 1024 * 1024


async def call_lines(session, tool, path, emit):
    with nullcontext(sys.stdin) if path == "-" else Path(path).open(encoding="utf-8") as stream:
        number = 0
        while True:
            # Keep the MCP transport event loop alive while an interactive caller waits.
            line = await asyncio.to_thread(stream.readline, MAX_LINE + 1)
            if not line:
                return 0
            number += 1
            if len(line.encode("utf-8")) > MAX_LINE:
                raise CliError(f"JSON Lines input {number} exceeds 32 MiB. Earlier calls may have succeeded.")
            try:
                data = json.loads(line)
            except ValueError:
                raise CliError(f"JSON Lines input {number} is invalid. Earlier calls may have succeeded.") from None
            if not isinstance(data, dict):
                raise CliError(f"JSON Lines input {number} must be an object. Earlier calls may have succeeded.")
            result = await session.call_tool(tool, data)
            emit(result_json(result))
            if result.is_error:
                return 1
