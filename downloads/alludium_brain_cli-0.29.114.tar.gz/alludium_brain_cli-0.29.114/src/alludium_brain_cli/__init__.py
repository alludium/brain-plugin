"""Alludium Brain's user CLI. No backend or model dependencies."""
