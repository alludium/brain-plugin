"""Thin transport adapter; discover schemas from the live server, never copy them."""

from contextlib import asynccontextmanager
from importlib.metadata import version

import httpx2
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client
from mcp.types import Implementation, PaginatedRequestParams


@asynccontextmanager
async def connect(url, auth=None, token=None):
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    async with (
        httpx2.AsyncClient(auth=auth, headers=headers, timeout=120, follow_redirects=False) as http,
        streamable_http_client(url, http_client=http) as (read, write),
        ClientSession(
            read,
            write,
            read_timeout_seconds=120,
            client_info=Implementation(name="alludium-brain-cli", version=version("alludium-brain-cli")),
        ) as session,
    ):
        await session.initialize()
        yield session


async def tools(session):
    found, cursor = [], None
    while True:
        page = await session.list_tools(params=PaginatedRequestParams(cursor=cursor) if cursor else None)
        found.extend(t.model_dump(mode="json", by_alias=True, exclude_none=True) for t in page.tools)
        if not page.next_cursor:
            return found
        cursor = page.next_cursor


def result_json(result):
    return result.model_dump(mode="json", by_alias=True, exclude_none=True)
