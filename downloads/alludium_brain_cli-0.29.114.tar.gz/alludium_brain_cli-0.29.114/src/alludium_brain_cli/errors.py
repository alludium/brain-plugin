"""Only these locally authored messages are safe to show without exposing HTTP secrets."""


class CliError(RuntimeError):
    pass


def diagnostic(error):
    if isinstance(error, CliError):
        return str(error)
    if isinstance(error, BaseExceptionGroup):
        for child in error.exceptions:
            if message := diagnostic(child):
                return message
    return None
