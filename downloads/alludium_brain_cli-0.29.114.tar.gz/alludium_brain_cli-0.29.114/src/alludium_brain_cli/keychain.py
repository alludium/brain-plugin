"""Credential access without surprise macOS dialogs.

Use per-query UI policy, never the global SecKeychainSetUserInteractionAllowed switch.
The small macOS bridge uses keyring's pinned CoreFoundation helpers; OAuth remains in auth.py.
"""

import ctypes
import sys

import keyring

from .errors import CliError


class Keychain:
    def __init__(self, *, allow_prompt=False):
        self.allow_prompt = allow_prompt

    def _mac(self, operation, service, account, value=None):
        from keyring.backends.macOS import api

        query = {
            "kSecClass": api.k_("kSecClassGenericPassword"),
            "kSecAttrService": service,
            "kSecAttrAccount": account,
            "kSecUseAuthenticationUI": api.k_(
                "kSecUseAuthenticationUIAllow" if self.allow_prompt else "kSecUseAuthenticationUIFail"
            ),
        }
        release = api._found.CFRelease
        release.argtypes = [ctypes.c_void_p]
        release.restype = None
        refs = []

        def cf(values):
            result = api.create_query(**values)
            refs.append(result)
            return result

        try:
            if operation == "read":
                result = ctypes.c_void_p()
                query.update(kSecMatchLimit=api.k_("kSecMatchLimitOne"), kSecReturnData=True)
                status = api.SecItemCopyMatching(cf(query), ctypes.byref(result))
                if status == api.error.item_not_found:
                    return None
                api.Error.raise_for_status(status)
                try:
                    return api.cfstr_to_str(result)
                finally:
                    release(result)
            if operation == "write":
                # SecItemUpdate requires CFData (SecItemAdd also accepts legacy CFString).
                data_create = api._found.CFDataCreate
                data_create.argtypes = (ctypes.c_void_p, ctypes.c_char_p, ctypes.c_long)
                data_create.restype = ctypes.c_void_p
                encoded = value.encode("utf-8")
                secret = ctypes.c_void_p(data_create(None, encoded, len(encoded)))
                refs.append(secret)
                update = api._sec.SecItemUpdate
                update.argtypes = (ctypes.c_void_p, ctypes.c_void_p)
                update.restype = api.OS_status
                # Update in place: preserve the item's access controls instead of delete/recreate.
                status = update(cf(query), cf({"kSecValueData": secret}))
                if status == api.error.item_not_found:
                    status = api.SecItemAdd(cf({**query, "kSecValueData": secret}), None)
            else:
                status = api.SecItemDelete(cf(query))
                if status == api.error.item_not_found:
                    return None
            api.Error.raise_for_status(status)
            return None
        finally:
            for ref in refs:
                release(ref)

    def _call(self, operation, service, account, value=None):
        try:
            if sys.platform == "darwin":
                return self._mac(operation, service, account, value)
            if operation == "read":
                return keyring.get_password(service, account)
            if operation == "write":
                return keyring.set_password(service, account, value)
            if keyring.get_password(service, account) is not None:
                keyring.delete_password(service, account)
            return None
        except Exception as exc:
            # OS/backend messages may contain account names or secret data.
            raise CliError(
                "Cannot access Alludium Brain CLI credentials in the OS keyring. "
                "On macOS, if you want to approve access, run "
                "brain login --allow-keychain-prompt yourself. No plaintext fallback was used."
            ) from exc

    def read(self, service, account):
        return self._call("read", service, account)

    def write(self, service, account, value):
        self._call("write", service, account, value)

    def delete(self, service, account):
        self._call("delete", service, account)
