# Alludium Brain CLI

Use `brain` from your terminal or scripts to call the same tools as your AI. No model runs in
the CLI. File bytes go straight to storage; the Brain still processes them using its usual
models, permissions and usage limits.

Download the wheel from [the public plugin repository](https://github.com/alludium/brain-plugin/tree/main/downloads).
Install with `uv tool install ./alludium_brain_cli-<version>-py3-none-any.whl` (or `pipx install`).
Python 3.12+ is required; uv can install it. An OS keyring is required for browser sign-in
(macOS Keychain, Windows Credential Locker or Linux Secret Service). On a headless machine,
inject an existing short-lived user token as `BRAIN_ACCESS_TOKEN` through your secret manager;
the CLI does not mint service accounts or bypass firm permissions.

```sh
brain login
brain tools > brain-tools.json
brain call search --input query.json
brain upload /path/to/vault --namespace research-vault --dry-run > plan.jsonl
brain upload /path/to/vault --namespace research-vault > receipts.jsonl
brain jobs job_123
brain logout
```

`login` first explains credential storage, then opens your browser and returns the server's
configuration, including your identity and workspace. Check those before importing. Credentials stay in the OS keyring. Scripts refresh
saved credentials but never open a browser automatically. `logout` removes this CLI's saved
credential, not the server authorization. `--server` / `BRAIN_SERVER` selects another MCP URL;
credentials are isolated by URL and callback port (default 8769). Concurrent commands for the
same profile serialize for token refresh; they fail after ten seconds waiting for the lock.

On macOS, commands disable Keychain approval dialogs by default. If macOS needs approval,
the command stops with a clear error. Run `brain login --allow-keychain-prompt` yourself only
when you intend to approve access to the `alludium-brain-cli` item. The dialog can name **Python**,
because that interpreter runs the CLI; changing Python installations may require fresh approval.
This is access to the CLI's own saved sign-in, not a request to enumerate your passwords.
The CLI does not relax Keychain access controls, unlock the Keychain, or fall back to plaintext.
It reads the entry once per command, updates it in place, and saves new OAuth registration details
only with a successful sign-in. A signed-out script stops before registering an OAuth client.

`tools` discovers live schemas. `call TOOL --input FILE` passes a JSON object verbatim; `--input -`
reads stdin. It supports every tool your account can access, including capture, search,
configuration and sharing. The command itself authorizes that tool call: there is no AI approval
dialogue. Read its schema and preview your inputs first. Full MCP results are JSON on stdout;
tool errors exit 1. Treat results as private data, and transfer URLs from a raw `request_upload`
call as credentials. The higher-level `upload` command suppresses transfer credentials.

For a finite batch, `brain call capture --jsonl --input reviewed.jsonl` reads one JSON object
per line and emits one complete MCP result per line. With `--input -`, a script can send one
line, wait for its result, then send the next. The CLI reuses one authenticated connection and
stops at the first malformed input, transport failure or tool error; earlier successes remain.
There are no automatic retries or transaction rollback. Each line is limited to 32 MiB.
Close stdin when finished; the saved-login profile lock lasts until the command exits.
The import starter uses this mode when available, still checking and flushing each receipt
before sending the next note. Older CLIs retain the one-command-per-record path.

`upload` accepts a file or recursively scans a folder for Markdown, text, HTML, PDF and Office
files. Hidden files/directories, temporary Office files and symlinks inside folders are skipped;
other extensions are ignored. Obsidian Markdown is uploaded as original Markdown; wikilinks,
frontmatter and attachments are not translated into graph relationships. Imports are private
unless you pass `--scope firm`. A dry run only hashes local files and emits metadata.

Each file produces one JSON line with its hash, source ID and job ID. Success means the transfer
was accepted, not that processing is complete: check `jobs`. A partial failure exits 1, keeps
successful receipts, and can be rerun. Unchanged files reuse the server's upload record. Changed
files are **additional snapshots**, identified by collection, relative path and hash; previous
versions remain. This is additive sync, not replacement or deletion mirroring. Keep the namespace
stable and unique per collection; do not run the same collection under different accounts or
change scope expecting it to reshare previous uploads. Use the sharing tool explicitly.

For custom integrations, have Claude or Codex write a script that reads the source locally and
calls `brain call capture --input ...` using schemas from `brain tools`. The data travels directly
from the script to the Brain. Store stable source-system IDs and URLs on captures. Avoid sending
contents or full result logs back into the conversation. Schedule the script with your own
scheduler if needed; the CLI has no watcher or scheduler.
